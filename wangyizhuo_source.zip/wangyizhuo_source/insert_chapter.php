<?php

use LDAP\Result;

session_start();

$chapter_name = $_POST['chapter_name'];
$chapter_content = $_POST['chapter_content'];
$novel_id = $_POST['novelId'];

date_default_timezone_set('Asia/Shanghai');
$create_time = date('Y-m-d H:i:s',time());
$update_time = $create_time;

//连接数据库
$conn = new mysqli('127.0.0.1','root','','wangyizhuo');
//设置字符集
$conn->set_charset("UTF8");
//准备sql，绑定用户参数
//检查账户是否已经存在
$sql = 'select * from `wangyizhuo_chapter` where chapterName = ? and novelId = ?';
$statement = $conn->prepare($sql);
$statement->bind_param('si',$chapter_name,$novel_id);
$statement->execute();
$result = $statement->get_result();

if($result->num_rows > 0){
    $_SESSION['message']['error'] = '章节名已被使用';
    return header('location: add_chapter.php');
}

//插入新的账户信息
$sql = 'insert into `wangyizhuo_chapter` values (null, ?, ?, ?, ?, ?)';
$statement = $conn->prepare($sql);
//发送请求缓存结果或者结果集
$statement->bind_param('ssiss',$chapter_name,$chapter_content,$novel_id,$create_time,$update_time);
$result = $statement->execute();
if($result){
    $_SESSION['message']['success'] = '章节添加成功';
    //添加新的账户信息
    $sql = 'update `wangyizhuo_novel` set updateTime = ? where novelId = ?';
    $statement = $conn->prepare($sql);
    //发送请求 缓存结果或者结果集
    $statement->bind_param('si',$create_time,$novel_id);
    $result = $statement->execute();

    return header('location: novel_chapters.php?nid='.$novel_id);
}else{
    $_SESSION['message']['error'] = '章节添加失败，请再次尝试';
    return header('location: add_chapter.php');
}