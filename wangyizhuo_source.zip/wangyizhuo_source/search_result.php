<?php
session_start();
$conn = new mysqli('127.0.0.1','root','','wangyizhuo');
$conn->set_charset('UTF8');

$keyword = '%'.$_POST['keyword'].'%';

$sql = 'SELECT DISTINCT n.novelId AS novelID, n.novelName AS novelName, n.novelImage AS novelImage, a.userEmail AS userEmail, n.novelDescription AS novelDes, n.updateTime AS novelUpdate 
        FROM wangyizhuo_chapter AS c 
        JOIN wangyizhuo_novel AS n ON c.novelId = n.novelId 
        JOIN wangyizhuo_accounts AS a ON n.authorId = a.userId 
        WHERE c.chapterName LIKE ? OR c.chapterContent LIKE ? OR n.novelName LIKE ? OR n.novelDescription LIKE ? OR a.userEmail LIKE ?';

$statement = $conn->prepare($sql);
$statement->bind_param('sssss', $keyword, $keyword, $keyword, $keyword, $keyword);
$statement->execute();
$result = $statement->get_result();

$novels = []; // 初始化为一个空数组

if ($result->num_rows > 0) {
    while ($novel = mysqli_fetch_assoc($result)) {
        $novels[] = $novel;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>王义卓 - 搜索结果</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/project.css">
</head>
<body>

<nav class="navbar navbar-inverse">
    <!-- 导航条代码省略 -->
</nav>

<div class="jumbotron">
    <div class="container">

        <div class="search-result">查询结果如下</div>
        <div class="row">
            <?php if (!empty($novels)): ?>
                <?php foreach ($novels as $novel): ?>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                    <a href="novel_chapters.php?nid=<?php echo htmlspecialchars($novel['novelID']); ?>" class="wrapper">
                        <div class="thumbnail">
                            <img src="<?php echo htmlspecialchars($novel['novelImage']); ?>" alt="<?php echo htmlspecialchars($novel['novelDes']); ?>" class="img-responsive">
                            <div class="caption text-center">
                                <h3><?php echo htmlspecialchars($novel['novelName']); ?></h3>
                                <p><?php echo htmlspecialchars($novel['userEmail']); ?><br><?php echo htmlspecialchars($novel['novelUpdate']); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>没有找到符合条件的小说。</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row">
    <ul class="list-inline text-center">
        <li>王义卓&nbsp;&nbsp;@</li><li><a href="http://www.fmp.edu.cn/" target="_blank">泥棒建設本屋</a></li>
    </ul>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
