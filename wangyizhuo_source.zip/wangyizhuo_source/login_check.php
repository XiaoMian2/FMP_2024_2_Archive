<?php

session_start();

$email = $_POST['email'];
$password = $_POST['password'];

//连接数据库
$conn = new mysqli('127.0.0.1','root','','wangyizhuo');
//设置字符集
$conn->set_charset('UTF8');
//准备sql，绑定用户参数
//查询用户名和密码是否在数据库里accounts存在
$sql = 'select * from `wangyizhuo_accounts` where userEmail = ? and userPassword = ?';
$statement = $conn->prepare($sql);
//发送请求，缓存结果或者结果集
$statement->bind_param('ss',$email,$password);
$statement->execute();
$result = $statement->get_result();
if($result->num_rows !=1){
    //不存在数据，则登录失败，返回登录页面
    $_SESSION['message']['error'] = '用户或者密码错误';
    return header('location: login.php');
}else{
    //登录成功，记录用户数据
    $user = $result->fetch_assoc();
    $_SESSION['message']['success'] = '欢迎回来，'.$user['userEmail'];
    $_SESSION['user'] = $user;
    return header('location: index.php');
}