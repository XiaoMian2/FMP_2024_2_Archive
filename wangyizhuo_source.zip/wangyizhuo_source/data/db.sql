drop database if exists `wangyizhuo`;
create database `wangyizhuo` charset=utf8;

use `wangyizhuo`;

drop table if exists `wangyizhuo_accounts`;
create table `wangyizhuo_accounts`
(
  `userId` int(10) unsigned primary key auto_increment,
  `userEmail` varchar(30) not null,
  `userPassword` char(50) not null
);

drop table if exists `wangyizhuo_novel`;
create table `wangyizhuo_novel`
(
  `novelId` int(10) unsigned primary key auto_increment,
  `novelName` varchar(15) not null,
  `novelDescription` text not null,
  `novelImage` varchar(60) not null,
  `authorId` int(10) unsigned not null,
  `createTime` datetime not null,
  `updateTime` datetime not null,
  foreign key (authorId) references wangyizhuo_accounts(userId)
);

drop table if exists `wangyizhuo_chapter`;
create table `wangyizhuo_chapter`
(
  `chapterId` int(10) unsigned primary key auto_increment,
  `chapterName` varchar(15) not null,
  `chapterContent` text not null,
  `novelId` int(10) unsigned not null,
  `createTime` datetime not null,
  `updateTime` datetime not null,
  foreign key (novelId) references wangyizhuo_novel(novelId)
);


insert into `wangyizhuo_accounts` values(null, 'wangyizhuo@qq.com', 'pass'),
                        (null, 'admin@qq.com', 'pass');

