<?php
session_start();

$novel_name = $_POST['novel_name'];
$novel_image = $_FILES['novel_image'];
$novel_desc = $_POST['novel_desc'];

if(!preg_match('/^image/',$novel_image['type'])){
    $_SESSION['message']['error'] = '只能上传图片';
    return header('location: create_new.php');
}

$novel_image_name = md5(time()+random_int(1,10000000)).'.'.pathinfo($novel_image['name'])['extension'];
$novel_image_path = 'images/'.$novel_image_name;
$author_id = $_SESSION['user']['userId'];

date_default_timezone_set('Asia/Shanghai');
$create_time = date('Y-m-d H:i:s');
$update_time = $create_time;
//连接数据库
$conn = new mysqli('127.0.0.1','root','','wangyizhuo');
//设置字符集
$conn->set_charset('UTF8');
//准备sql，绑定用户参数
//检查账户是否已经存在
$sql = 'select * from `wangyizhuo_novel` where novelName = ? and authorId = ?';
$statement = $conn->prepare($sql);
//发送请求，缓存结果或者结果集
$statement->bind_param('si',$novel_name,$author_id);
$statement->execute();
$result = $statement->get_result();

if($result->num_rows > 0){
    $_SESSION['message']['error'] = '您已经创建过这本书了';
    return header('location: create_new.php');
}
//插入新的账户信息
$sql = 'insert into `wangyizhuo_novel` values (null,?,?,?,?,?,?)';
$statement = $conn->prepare($sql);
//发送请求，缓存结果或者结果集
$statement->bind_param('sssiss',$novel_name,$novel_desc,$novel_image_path,$author_id,$create_time,$update_time);
$result = $statement->execute();

if($result){
    $_SESSION['message']['success'] = '创建成功';
    move_uploaded_file($novel_image['tmp_name'],$novel_image_path);
    return header('location: index.php');
}else{
    $_SESSION['message']['error'] = '创建失败，请再次尝试';
    return header('location: create_new.php');
}